from flask import Flask

from lib import verifyGeo

# If you get an error on the next line on Python 3.4.0, change to: Flask('app')
# where app matches the name of this file without the .py extension.
app = Flask(__name__)

# Attempt to pull the GPS using the geolocation functionality of networks
verifyGeo();



from routes import *


if __name__ == '__main__':
    import os
    host = os.environ.get('SERVER_HOST', 'localhost')
    try:
        port = int(os.environ.get('SERVER_PORT', '5550'))
    except ValueError:
        port = 5550
    app.run(host, port, debug=True)
