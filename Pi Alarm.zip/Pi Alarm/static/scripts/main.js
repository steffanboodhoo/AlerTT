(function(window){
	"use strict";

	var alarm_status,
		form_after_action;

	$(document).ready(function(){
		
		console.log("Loaded and ready to go");

		getAlarmStatus(function(status){
			alarm_status = status;
			updateButton(status);
		});

		$("#submitPasscode").submit(onPasscodeFormSubmit);
		$("#messageModal").submit(onMessageFormSubmit);
		$("#submitupdatePasscode").submit(onPasscodeChange);

		$("#btnSend").click(function(){
			promptPasscode(sendMessageSvr);
		});

		$("#btnEnable").click(function(){
			promptPasscode(changeAlarmStatus);
		});

		$("#btnPasscode").click(function(){
			promptPasscode(changePassword);
		});
	});


	function promptPasscode(callback){
		form_after_action = callback;
		$('#passcodeModal').modal();
	}

	function onPasscodeChange(evt){
		var passcode = $("#passcode").val();
		if (passcode.length > 0){
			$.post("/api/user/passcode", {"passcode": passcode}, function(res){
				if (res === 1)displayConfirmation("Password Updated");
				else displayError("Unable to update Password");
			});
		}
	}

	function onMessageFormSubmit(evt){
		var message = $("#messageTxt").val(),
			type = $("#type option:selected" ).text(),
			subject = $("#subjTxt").val();


		console.log(type);

		$.ajax({
			url: "/api/message",
			method: "POST",
			data: {'message':message, 'subject': subject,'type':type},
			success: function(res){
				console.log("Successful "+res);
				displayConfirmation("Successfully sent message");
			},
			error: function(err){
				displayError("Unable to send message");
				console.log(err);
			}
		});

		$('#messageModal').modal('hide');

		return false;
	}

	function onPasscodeFormSubmit(evt){
		var passcode = $("#passcode").val();
		if (passcode.length > 0){
			$.post("/api/user/login", {"passcode": passcode}, function(res){
				if (res === "1" && form_after_action)
					form_after_action();
				else
					displayError("Incorrect Passcode");
			});
		}
		$('#passcodeModal').modal('hide');
		return false;
	}

	function changePassword(){
		$('#passcodeChangeModal').modal();
	}

	function sendMessageSvr(){
		$('#messageModal').modal();
	}

	function changeAlarmStatus(){
		if (alarm_status){
			if (alarm_status === "0"){
				alarm_status = "1";
				$.post("/api/sys_on", function(){
					console.log("Alarm_system Activated");	
					displayConfirmation("Alarm System Activated");
				});	
			}
			else {
				alarm_status = "0";				
				$.post("/api/sys_off", function(){
					console.log("Alarm System Deactivated");
					displayConfirmation("Alarm System Deactivated");
				});
			}

			$.post("/api/alarm_status/"+alarm_status, function(status){
				console.log(status);
				alarm_status = status;
				updateButton(status);
			});
		}
	}

	function displayError(msg){
		$("#alertSec").html('<div class="alert alert-danger" role="alert">'+ msg +'</div>');
	}

	function displayConfirmation(msg){
		$("#alertSec").html('<div class="alert alert-success" role="alert">'+ msg +'</div>');
	}

	function updateButton(status){
		if (status === "0")enableButton();
		else disableButton();
	}

	function enableButton(){
		$("#btnEnable")
			.removeClass("btn-danger")
			.html("Enable Alarm")
			.addClass("btn-success");
	}

	function disableButton(){
		$("#btnEnable")
			.removeClass("btn-success")
			.html("Disable Alarm")
			.addClass("btn-danger");
	}

	function getAlarmStatus(callback){
		$.get("/api/alarm_status", function(data){
			console.log(data);
			callback(data);
		})
	}

	

}(this));
