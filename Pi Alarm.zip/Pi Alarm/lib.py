import requests
import GeoIP
import sys
import os.path
import hashlib
import time
sys.path.append( "./ipgetter" )
import ipgetter

#default addresses
glb_gps_lat = "10.650649" 
gbl_gps_long = "-61.425365"
gbl_passcode = "202cb962ac59075b964b07152d234b70"


def sendAlert(message, subject, msgtype, gps_lat=None, gps_long=None):
	global glb_gps_lat
	global gbl_gps_long

	if (gps_lat == None):
		gps_lat = glb_gps_lat
	if (gps_long == None):
		gps_long = gbl_gps_long

	domain = "https://1-dot-sinuous-moment-658.appspot.com"
	AppEng_url = domain + "/_ah/api/locationlistenerendpoint/v1/alertPeople/"
	AppEng_url = AppEng_url + message + "/" + subject + "/" + msgtype + "/" + gps_lat +"/" + gps_long
	r = requests.post(AppEng_url)
	print("Alarm Triggered")

def geoid():
	global glb_gps_lat
	global gbl_gps_long

	myip = ipgetter.myip()
	gi = GeoIP.open("./GeoLiteCity.dat", GeoIP.GEOIP_STANDARD)
	gir = gi.record_by_addr(str(myip))
	f = open('gps.txt', 'w')

	if gir is not None:
		print(gir['latitude'])
		glb_gps_lat = gir['latitude']
		print(gir['longitude'])
		gbl_gps_long = gir['longitude']
		f.write(str(gir['latitude']) +","+ str(gir['longitude']))
 
def verifyGeo():
	global glb_gps_lat
	global gbl_gps_long

	path = os.path.dirname(os.path.abspath(__file__))

	if(os.path.exists(path+"/gps.txt")):
		f = open('gps.txt', 'r')
		strGPS = f.read()
		gpsArr = strGPS.split(",")

		glb_gps_lat = gpsArr[0]
		gbl_gps_long = gpsArr[1]
	else:
		geoid()

def verifyPasscode():
	global gbl_passcode
	if(os.path.isfile("./passcode.txt")):
		f = open('passcode.txt', "r")
		gbl_passcode = f.read()

def savePasscode(passcode=None):
	f = open('passcode.txt', "w")
	if (passcode):
		gbl_passcode = passcode
	f.write(gbl_passcode)

def hashPassword(password):
	m = hashlib.md5()
	m.update(password)
	return m.hexdigest()

def comparePassword(password):
	global gbl_passcode
	m = hashlib.md5()
	m.update(password)
	if (m.hexdigest() == gbl_passcode):
		return True
	return False

def startListenerThread():
	
	import RPi.GPIO as io
	io.setmode(io.BOARD)
	print("thread started")

	# Magnetic Door Switch located on the pin 7
	global alarmTriggered
	alarmTriggered=False
	io.setup(7,io.IN,pull_up_down=io.PUD_UP)
	while True and alarmTriggered==False:
  		if io.input(7):
			print("Alarm triggered")
   			sendAlert("Break In detected","Break In","warning")
			alarmTriggered=True
   		time.sleep(0.5)


def callbackFunc(channel):
	global alarmTriggered
	alarmTriggered = True
	print "Callback executed"
	sendAlert("Break In detected","Break In","warning")
	
def startListenerThread2():
	global alarmTriggered	
	import RPi.GPIO as io
	io.setmode(io.BOARD)
	io.setup(7,io.IN,pull_up_down=io.PUD_UP)
	io.add_event_detect(7, io.RISING,callback=callbackFunc) 

def removeListenerThread():
	import RPi.GPIO as io
	io.setmode(io.BOARD)
	io.remove_event_detect(7)
	
# startListenerThread2()
# startListenerThread()
	
