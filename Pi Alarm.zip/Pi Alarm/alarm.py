#this code does the simple activation when the strip is seperated

# import RPi.GPIO as io
import time

from lib import sendAlert

# io.setmode(io.BOARD)
# io.setup(7,io.IN,pull_up_down=io.PUD_UP)
# domain = "https://1-dot-sinuous-moment-658.appspot.com"
# AppEng_url = domain + "/_ah/api/locationlistenerendpoint/v1/alertPeople/"
message = "House break in progress"
gps_lat = "10.650649"
gps_long = "-61.425365"

# AppEng_url = AppEng_url + message + "/" + gps_lat +"/" + gps_long



# while True:
    # if io.input(7):
    	# deactivateAlarm()
#"sending to server" code need here
    # time.sleep(0.5)
 


sendAlert("HelloWorld",gps_lat,gps_long)