from datetime import datetime
from flask import render_template, request
from app import app
import os
from lib import *

alarm_enable=0

@app.route('/')
@app.route('/home')
def home():
    
    return render_template(
        'index.html',
        title = 'Home Page',
        year = datetime.now().year,
    )


@app.route('/api/alarm_status')
def get_status():
    global alarm_enable
    return str(alarm_enable)

@app.route('/api/alarm_status/<int:idV>', methods=['POST'])
def set_status(idV):
    global alarm_enable
    alarm_enable = idV
    return str(alarm_enable)


@app.route('/api/user/login', methods=['POST'])
def user_login():
    passcode = request.form['passcode']
    print(str(passcode))
    if (comparePassword(passcode)):
        return str(1)
    return str(0)

@app.route('/api/user/passcode', methods=['POST'])
def update_passcode():
    try:
        passcode = request.form['passcode']
        print(str(passcode))
        hashPass = hashPassword(passcode)
        savePasscode(hashPass)
        return "1"
    except Exception:
        return "0"



@app.route('/api/message', methods=['POST'])
def messenger():
    message = request.form['message']
    typeS = request.form['type']
    subject = request.form['subject']

    sendAlert(message,subject,typeS)

    return str(0)

@app.route('/api/sys_on', methods=['POST'])
def ActivateAlarm():
    startListenerThread2()
    return str(0)
